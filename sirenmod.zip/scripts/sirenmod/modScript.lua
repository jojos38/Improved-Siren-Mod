extensions.load("sirenmod")
registerCoreModule("sirenmod")